# Barcode Scanner Executable 


## Project setup

1. create virtual environment

```
python -m venv venv
venv\Scripts\activate
```

2. install dependencies

```
pip install -r requirements.txt
```


## How to use
1. Run the python script and pass arguements

Barcode_Type: 'code128'|'ean13'|'upca'
Barcode: "Whatever data you desire"
Width: Defaults to 0.2
Height: Defaults to 15.0

```
// .\GenerateBarcode.exe <Barcode_Type> <Barcode> <File_Name> <Width> <Height>

.\GenerateBarcode.exe "code128" "I000000" "sample" 0.3 5.0

```

2. Create the executable for using with other languages, it will be found in the dist folder.

```
pyinstaller --onefile GenerateBarcode.py
```