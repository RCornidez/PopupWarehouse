import sys
import os
from barcode import Code128, EAN13, UPCA
from barcode.writer import SVGWriter

def generate_barcode(barcode_type, data, filename, module_width=0.2, module_height=15.0):
    """
    Generates a barcode SVG image of specified type and size, and saves it to a specified filename within a fixed directory.

    Args:
    - barcode_type (str): The type of the barcode (e.g., 'code128', 'ean13', 'upca').
    - data (str): The data to encode in the barcode.
    - filename (str): The filename for the saved image, without extension.
    - module_width (float): The width of one barcode module in mm.
    - module_height (float): The height of the barcode modules in mm.
    """
    # Define the output directory
    output_dir = "barcode/temp/"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Full path for the output file, ensuring it ends with .svg
    output_file = os.path.join(output_dir, filename)

    # Selecting the barcode class based on the type
    barcode_classes = {
        'code128': Code128,
        'ean13': EAN13,
        'upca': UPCA
    }
    barcode_class = barcode_classes.get(barcode_type.lower())
    if barcode_class is None:
        print(f"Unsupported barcode type: {barcode_type}")
        return

    # Generate the barcode using SVGWriter
    barcode = barcode_class(data, writer=SVGWriter())

    # Save the barcode SVG image with specified options
    options = {
        'module_width': module_width,
        'module_height': module_height,
        # Additional options can be specified as needed
    }
    barcode.save(output_file, options)

    print(f"Barcode SVG saved to {output_file}")

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: generate_barcode.py <barcode_type> <data> <filename_without_extension> <module_width> <module_height>")
        sys.exit(1)
    
    barcode_type, data, filename = sys.argv[1], sys.argv[2], sys.argv[3]
    module_width, module_height = float(sys.argv[4]), float(sys.argv[5])
    
    generate_barcode(barcode_type, data, filename, module_width, module_height)
